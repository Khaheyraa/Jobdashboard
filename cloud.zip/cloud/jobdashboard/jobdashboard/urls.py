from django.contrib import admin
from django.urls import path
from jobs import views as job_views
from django.contrib.auth import views as auth_views

from django.conf import settings
from django.conf.urls.static import static  # for serving media

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', job_views.login_view, name='login'),  # Custom login view
    path('home/', job_views.home, name='home'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
    path('apply/<int:job_id>/', job_views.apply_job, name='apply_job'),
]

# ✅ Serve media files (resume upload)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

