# jobs/models.py

from django.db import models
# jobs/forms.py
from django.contrib.auth.models import User # ✅ Fix the name



JOB_TYPES = (
    ('Full Time', 'Full Time'),
    ('Part Time', 'Part Time'),
    ('Internship', 'Internship'),
    ('Freelance', 'Freelance'),
    ('Contractual', 'Contractual'),
)

REMOTE_OPTIONS = (
    ('On Site', 'On Site'),
    ('Remote', 'Remote'),
    ('Hybrid', 'Hybrid'),
)

class Job(models.Model):
    title = models.CharField(max_length=200)
    company = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    job_type = models.CharField(choices=JOB_TYPES, max_length=50)
    remote_type = models.CharField(choices=REMOTE_OPTIONS, max_length=20)
    level = models.CharField(max_length=50)
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} at {self.company}"

class JobApplication(models.Model):
    job = models.ForeignKey(Job, on_delete=models.CASCADE)
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    resume = models.FileField(upload_to='resumes/')
    applied_at = models.DateTimeField(auto_now_add=True)





class Resume(models.Model):
    name = models.CharField(max_length=100)
    file = models.FileField(upload_to='resumes/')

    def __str__(self):
        return self.name


