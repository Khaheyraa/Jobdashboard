# jobs/views.py

from django.shortcuts import render, get_object_or_404, redirect
from .models import Job
from .forms import ApplicationForm
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth.decorators import login_required


from .models import JobApplication

from django.core.mail import send_mail
from django.conf import settings

@login_required  
def apply_job(request, job_id):
    from .forms import ApplicationForm
    job = Job.objects.get(id=job_id)
    if request.method == 'POST':
        resume = request.FILES.get('resume')
        JobApplication.objects.create(job=job, user=request.user, resume=resume)

        # ✅ Send email confirmation
        subject = f"Application Received for {job.title}"
        message = (
            f"Hi {request.user.first_name or request.user.username},\n\n"
            f"Your application for the role '{job.title}' at {job.company} "
            f"has been received successfully.\n\n"
            "We’ll get back to you soon!\n\n"
            "Best regards,\nJobLab Team"
        )
        recipient_list = [request.user.email]

        send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, recipient_list)

        return render(request, 'jobs/apply_success.html', {'job': job})

    return render(request, 'jobs/apply.html', {'job': job})



from django.core.mail import send_mail
from django.http import HttpResponse

def test_email(request):
    send_mail(
        'SMTP Test',
        'Django SMTP email works fine!',
        'your_email@gmail.com',
        ['your_email@gmail.com'],
        fail_silently=False,
    )
    return HttpResponse("Email sent successfully!")

from .models import Job

def home(request):
    jobs = Job.objects.all()

    # Filter logic
    job_type = request.GET.get('type')
    remote = request.GET.get('remote')
    min_salary = request.GET.get('min_salary')

    if job_type:
        jobs = jobs.filter(job_type=job_type)
    if remote:
        jobs = jobs.filter(remote_type=remote)
    if min_salary:
        jobs = jobs.filter(salary__gte=min_salary)

    return render(request, 'jobs/home.html', {'jobs': jobs})
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect

def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')
    
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'jobs/login.html', {'error': 'Invalid username or password'})
    
    return render(request, 'jobs/login.html')




